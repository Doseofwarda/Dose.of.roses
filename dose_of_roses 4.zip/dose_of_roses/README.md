# Dose_of_roses

A Pen created on CodePen.io. Original URL: [https://codepen.io/fbmjdnis-the-scripter/pen/raBxOOj](https://codepen.io/fbmjdnis-the-scripter/pen/raBxOOj).

